#' Simulated competing risks survival dataset
#'
#'  A simulated dataset used to illustrate some models (e.g., example of joint() function in the documentation). The corresponding longitudinal dataset is named 'Longsim'.
#'
#' @format ## `Survsim`
#' A data frame with 15 rows and 5 columns:
#' \describe{
#'   \item{Id}{Individual id}
#'   \item{deathTimes}{Event time}
#'   \item{ctsX}{Continuous covariate}
#'   \item{binX}{Binary covariate}
#'   \item{Event1, Event2, Event3}{Event indicator for the 3 competing risks (individual is censored when the 3 events are 0)}
#'   ...
#' }
"Survsim"
